<?php

session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MENU</title>
</head>
<body>
    <h1 >Cadastro Dos Veiculos</h1>
    <h2 >Olá Mundo</h2>
    <a href="./cadastrar.php"><button>Cadastrar Alunos e Carros</button></a>
    <a href="./cadastro.php"><button>Ver cadastros</button></a>
    <a href="./sair.php" ><button>Sair</button></a>
    <br>
    




</body>
</html>

